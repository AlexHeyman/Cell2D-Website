=== RUNNING THE GAME ===

To run Asteroid Field, run AsteroidField.jar, the executable jar file in this directory. If your operating system prompts you to select a program to open it with, select Java. If the game fails to run, make sure you have the latest version of Java.

=== CREDITS ===

Design: Andrew Heyman
Programming: Andrew Heyman
Graphics: Andrew Heyman
Sounds: ChipTone
Made with Cell2D
