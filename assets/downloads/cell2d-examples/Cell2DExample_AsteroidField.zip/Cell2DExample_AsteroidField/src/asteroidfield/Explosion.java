package asteroidfield;

import org.cell2d.Frac;
import org.cell2d.space.CircleHitbox;
import org.cell2d.space.basic.BasicThinkerObject;

/**
 * A short-lived explosion effect that a Spaceship creates when it is destroyed.
 * @author Andrew Heyman
 */
public class Explosion extends BasicThinkerObject {
    
    public Explosion(long x, long y) {
        Game.SND_EXPLODE.play();
        setLocatorHitbox(new CircleHitbox(x, y, 48*Frac.UNIT));
        setAnimation(Game.ANIM_EXPLOSION).setSpeed(Frac.UNIT);
        setTimerValue((game, state) -> {
            state.removeObject(Explosion.this);
        }, 9);
    }
    
}
