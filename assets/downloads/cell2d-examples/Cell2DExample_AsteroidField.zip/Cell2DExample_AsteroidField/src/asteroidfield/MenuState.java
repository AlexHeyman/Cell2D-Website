package asteroidfield;

import org.cell2d.CellGame;
import org.cell2d.basic.BasicState;
import org.cell2d.celick.Graphics;

/**
 * A GameState that implements the main menu.
 * @author Alex Heyman
 */
public class MenuState extends BasicState {
    
    private static final String[] OPTIONS = {"START GAME", "CREDITS", "QUIT"};
    private static final int OPTION_HEIGHT = 32;
    
    private final Game game;
    private int option;
    
    public MenuState(Game game) {
        super(game, Game.SID_MENU);
        this.game = game;
    }
    
    @Override
    public void enteredActions(CellGame game) {
        option = 0;
    }
    
    @Override
    public void frameActions(CellGame game, BasicState state) {
        if (game.commandPressed(Game.CMD_DOWN)) {
            Game.SND_CHANGE_OPTION.play();
            option++;
            if (option == OPTIONS.length) {
                option = 0;
            }
        } else if (game.commandPressed(Game.CMD_UP)) {
            Game.SND_CHANGE_OPTION.play();
            option--;
            if (option == -1) {
                option = OPTIONS.length - 1;
            }
        }
        if (game.commandPressed(Game.CMD_SELECT)) {
            switch (option) {
                case 0:
                    Game.SND_SELECT.play();
                    new InGameState(this.game);
                    this.game.fadeEnterState(Game.SID_INGAME);
                    break;
                case 1:
                    Game.SND_SELECT.play();
                    this.game.fadeEnterState(Game.SID_CREDITS);
                    break;
                case 2:
                    game.close();
                    break;
            }
        }
    }
    
    @Override
    public void renderActions(CellGame game, Graphics g, int x1, int y1, int x2, int y2) {
        Game.drawString("ASTEROID FIELD", g, x1 + 144, y1 + 128);
        Game.drawString("HIGH SCORE: " + this.game.getHighScore(), g, x1 + 144, y1 + 160);
        int optionsX = x1 + 176;
        int optionsY = y1 + 256;
        for (int i = 0; i < OPTIONS.length; i++) {
            Game.drawString(OPTIONS[i], g, optionsX, optionsY + i*OPTION_HEIGHT);
        }
        Game.SPR_ARROW.draw(g, optionsX - 16, optionsY + option*OPTION_HEIGHT);
    }
    
}
