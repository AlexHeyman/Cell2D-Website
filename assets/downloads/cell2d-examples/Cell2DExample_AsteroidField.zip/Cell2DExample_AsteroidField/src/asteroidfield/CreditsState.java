package asteroidfield;

import org.cell2d.CellGame;
import org.cell2d.basic.BasicState;
import org.cell2d.celick.Graphics;

/**
 * A GameState that displays the game's credits. From here, the player can only
 * return to the main menu.
 * @author Alex Heyman
 */
public class CreditsState extends BasicState {
    
    private final Game game;
    
    public CreditsState(Game game) {
        super(game, Game.SID_CREDITS);
        this.game = game;
    }
    
    @Override
    public void frameActions(CellGame game, BasicState state) {
        if (game.commandPressed(Game.CMD_SELECT)) {
            Game.SND_SELECT.play();
            this.game.fadeEnterState(Game.SID_MENU);
        }
    }
    
    @Override
    public void renderActions(CellGame game, Graphics g, int x1, int y1, int x2, int y2) {
        Game.drawString("CREDITS", g, x1 + 200, y1 + 20);
        Game.drawString("Design - Alex Heyman", g, x1 + 16, y1 + 60);
        Game.drawString("Programming - Alex Heyman", g, x1 + 16, y1 + 80);
        Game.drawString("Graphics - Alex Heyman", g, x1 + 16, y1 + 100);
        Game.drawString("Sounds - ChipTone", g, x1 + 16, y1 + 120);
        Game.drawString("Made with Cell2D", g, x1 + 16, y1 + 160);
        Game.drawString("RETURN", g, x1 + 64, y1 + 200);
        Game.SPR_ARROW.draw(g, x1 + 48, y1 + 200);
    }
    
}
