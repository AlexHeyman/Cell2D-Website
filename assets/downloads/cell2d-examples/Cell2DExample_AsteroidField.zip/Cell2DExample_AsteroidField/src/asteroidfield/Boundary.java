package asteroidfield;

import org.cell2d.Direction;
import org.cell2d.space.RectangleHitbox;
import org.cell2d.space.SpaceObject;

/**
 * A solid horizontal barrier at the top or bottom of an InGameState's playing
 * field. It prevents the Spaceship from moving above or below the screen.
 * @author Andrew Heyman
 */
public class Boundary extends SpaceObject {
    
    public Boundary(long x1, long x2, long y, boolean bottom) {
        setLocatorHitbox(new RectangleHitbox(x1, y, 0, x2 - x1, 0, 0));
        setSolidHitbox(getLocatorHitbox());
        setSurfaceSolid((bottom ? Direction.UP : Direction.DOWN), true);
    }
    
}
