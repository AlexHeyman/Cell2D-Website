package asteroidfield;

import org.cell2d.CellGame;
import org.cell2d.Frac;
import org.cell2d.space.CircleHitbox;
import org.cell2d.space.basic.BasicSpaceState;
import org.cell2d.space.basic.BasicThinkerObject;

/**
 * An asteroid that the Spaceship has to dodge. It spins at a constant rate. If
 * it was visible (that is, on the playing field) in the past, but is no longer
 * visible, it will disappear.
 * @author Andrew Heyman
 */
public class Asteroid extends BasicThinkerObject {
    
    public static final long RADIUS = 32*Frac.UNIT;
    
    private final double spin;
    private boolean hasBeenVisible = false;
    
    public Asteroid(long x, long y, double spin) {
        setLocatorHitbox(new CircleHitbox(x, y, RADIUS));
        setOverlapHitbox(getLocatorHitbox());
        setAngle(Math.random() * 360);
        setAppearance(Game.SPR_ASTEROID);
        setDrawPriority(-1);
        this.spin = spin;
    }
    
    @Override
    public void frameActions(CellGame game, BasicSpaceState state) {
        changeAngle(spin);
        boolean visible = isVisible();
        if (visible) {
            hasBeenVisible = true;
        } else if (hasBeenVisible) {
            state.removeObject(this);
        }
    }
    
}
