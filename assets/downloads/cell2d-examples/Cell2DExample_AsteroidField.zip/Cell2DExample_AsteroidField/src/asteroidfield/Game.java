package asteroidfield;

import org.cell2d.Animation;
import org.cell2d.CellGame;
import org.cell2d.Color;
import org.cell2d.Frac;
import org.cell2d.Sound;
import org.cell2d.Sprite;
import org.cell2d.SpriteSheet;
import org.cell2d.celick.Graphics;
import org.cell2d.control.KeyControl;

/**
 * The main class of Asteroid Field, a simple game in which you steer a
 * spaceship to avoid asteroids. A single instance of this class represents the
 * game as a whole.
 * @author Andrew Heyman
 */
public class Game extends CellGame {
    
    public static final int NUM_COMMANDS = 3;
    public static final int CMD_UP = 0;
    public static final int CMD_DOWN = 1;
    public static final int CMD_SELECT = 2;
    public static final int SCREEN_WIDTH = 512;
    public static final long SCREEN_WIDTH_FRAC = SCREEN_WIDTH*Frac.UNIT;
    public static final int SCREEN_HEIGHT = 512;
    public static final long SCREEN_HEIGHT_FRAC = SCREEN_HEIGHT*Frac.UNIT;
    public static final int FONT_WIDTH = 16;
    public static final Color FADE_COLOR = Color.BLACK;
    public static final int FADE_TIME = 15;
    public static final int SID_MENU = 0;
    public static final int SID_CREDITS = 1;
    public static final int SID_INGAME = 2;
    public static final int MAX_SCORE = 99999999;
    public static Sprite
            SPR_ARROW,
            SPR_ASTEROID;
    public static SpriteSheet
            SPS_FONT;
    public static Animation
            ANIM_SPACESHIP,
            ANIM_EXPLOSION;
    public static Sound
            SND_CHANGE_OPTION,
            SND_SELECT,
            SND_EXPLODE;
    
    private int highScore = 0;
    
    public Game() {
        super("Asteroid Field", NUM_COMMANDS, 60, SCREEN_WIDTH, SCREEN_HEIGHT, 1, false, null);
    }
    
    @Override
    public void initActions() {
        bindControl(CMD_UP, new KeyControl(KeyControl.KEY_UP));
        bindControl(CMD_DOWN, new KeyControl(KeyControl.KEY_DOWN));
        bindControl(CMD_SELECT, new KeyControl(KeyControl.KEY_ENTER));
        
        Color cyan = new Color(0, 255, 255);
        Color green = new Color(0, 255, 0);
        
        SPR_ARROW = new Sprite("assets/graphics/arrow.png", 8, 0, cyan, null, true);
        SPR_ASTEROID = new Sprite("assets/sprites/asteroid.png", 32, 32, cyan, null, true);
        SPS_FONT = new SpriteSheet("assets/graphics/font.png", 94, 1, 16, 20, 0, 0, 0, cyan, null, true);
        
        SpriteSheet spaceship = new SpriteSheet(
                "assets/sprites/spaceship.png", 1, 2, 101, 48, 4, 53, 24, green, null, true);
        ANIM_SPACESHIP = new Animation(spaceship, 0, 0, 0, 1, true, 3*Frac.UNIT, 3*Frac.UNIT);
        
        SpriteSheet explosion = new SpriteSheet(
                "assets/sprites/explosion.png", 3, 1, 96, 96, 0, 48, 48, cyan, null, true);
        ANIM_EXPLOSION = new Animation(explosion, 0, 0, 2, 0, false, 3*Frac.UNIT, 3*Frac.UNIT, 0);
        
        SND_CHANGE_OPTION = new Sound("assets/sounds/changeoption.wav", true);
        SND_SELECT = new Sound("assets/sounds/select.wav", true);
        SND_EXPLODE = new Sound("assets/sounds/explode.wav", true);
        
        new CreditsState(this);
        new MenuState(this);
        
        enterState(SID_MENU);
    }
    
    public final void fadeEnterState(int id) {
        enterState(id, FADE_COLOR, FADE_TIME, FADE_TIME);
    }
    
    public final int getHighScore() {
        return highScore;
    }
    
    public final void recordScore(int score) {
        highScore = Math.max(highScore, score);
    }
    
    public static void drawString(String s, Graphics g, int x, int y) {
        for (int i = 0; i < s.length(); i++) {
            int charIndex = (int)(s.charAt(i)) - 33;
            if (charIndex >= 0 && charIndex < SPS_FONT.getWidth()) {
                SPS_FONT.getSprite(charIndex, 0).draw(g, x, y);
            }
            x += FONT_WIDTH;
        }
    }
    
    public static void main(String[] args) {
        CellGame.loadNatives("natives");
        CellGame.startGame(new Game());
    }
    
}
