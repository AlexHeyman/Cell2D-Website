package asteroidfield;

import org.cell2d.CellGame;
import org.cell2d.Frac;
import org.cell2d.space.RectangleHitbox;
import org.cell2d.space.basic.BasicSpaceState;
import org.cell2d.space.basic.BasicThinkerObject;

/**
 * A spaceship that the player can move up and down. If it touches an Asteroid,
 * it will be destroyed.
 * @author Alex Heyman
 */
public class Spaceship extends BasicThinkerObject {
    
    public Spaceship(long x, long y) {
        setLocatorHitbox(new RectangleHitbox(x, y,
                -53*Frac.UNIT, 48*Frac.UNIT, -24*Frac.UNIT, 24*Frac.UNIT));
        setOverlapHitbox(new RectangleHitbox(0, 0,
                -48*Frac.UNIT, 48*Frac.UNIT, -24*Frac.UNIT, 24*Frac.UNIT));
        setCollisionHitbox(getOverlapHitbox());
        setCollision(true);
        setAnimation(Game.ANIM_SPACESHIP).setSpeed(Frac.UNIT);
    }
    
    @Override
    public void beforeMovementActions(CellGame game, BasicSpaceState state) {
        if (game.commandHeld(Game.CMD_DOWN)) {
            setVelocityY(3*Frac.UNIT);
        } else if (game.commandHeld(Game.CMD_UP)) {
            setVelocityY(-3*Frac.UNIT);
        } else {
            setVelocityY(0);
        }
    }
    
    @Override
    public void frameActions(CellGame game, BasicSpaceState state) {
        if (isOverlappingObject(Asteroid.class)) {
            state.removeObject(this);
            state.addObject(new Explosion(getX(), getY()));
        }
    }
    
}
