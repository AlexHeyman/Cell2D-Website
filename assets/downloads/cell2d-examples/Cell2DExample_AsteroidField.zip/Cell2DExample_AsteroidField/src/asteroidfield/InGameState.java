package asteroidfield;

import org.cell2d.CellGame;
import org.cell2d.Frac;
import org.cell2d.space.MobileObject;
import org.cell2d.space.SpaceObject;
import org.cell2d.space.Viewport;
import org.cell2d.space.basic.BasicSpaceEvent;
import org.cell2d.space.basic.BasicSpaceState;

/**
 * A SpaceState in which Asteroid Field's actual gameplay takes place. It
 * creates a Spaceship for the player to control, spawns Asteroids that destroy
 * the Spaceship on contact, and increases the current score the longer the
 * Spaceship remains in existence. After the Spaceship has been destroyed, the
 * game returns to the main menu. An InGameState is never entered more than
 * once; if the player chooses to start the game again, a new InGameState will
 * be created to replace the old one.
 * @author Alex Heyman
 */
public class InGameState extends BasicSpaceState {
    
    private final Game game;
    private SpaceObject spaceship;
    private int score = 0;
    
    private final BasicSpaceEvent incrementScore = new BasicSpaceEvent() {
        
        @Override
        public void actions(CellGame game, BasicSpaceState state) {
            if (score < Game.MAX_SCORE) {
                score++;
                setTimerValue(incrementScore, 60);
            }
        }
        
    };
    private final BasicSpaceEvent spawnAsteroid = new BasicSpaceEvent() {
        
        @Override
        public void actions(CellGame game, BasicSpaceState state) {
            int row = (int)Math.floor(Math.random() * 8);
            MobileObject asteroid = new Asteroid(
                    Game.SCREEN_WIDTH_FRAC + Asteroid.RADIUS, 32*Frac.UNIT + row * 64*Frac.UNIT,
                    (Math.random() < 0.5 ? 1 : -1));
            asteroid.setVelocityX(-3*Frac.UNIT);
            addObject(asteroid);
            setTimerValue(spawnAsteroid, 30);
        }
        
    };
    
    public InGameState(Game game) {
        super(game, Game.SID_INGAME, Game.SCREEN_WIDTH_FRAC, Game.SCREEN_HEIGHT_FRAC, DrawMode.FLAT);
        this.game = game;
        addObject(new Boundary(0, Game.SCREEN_WIDTH_FRAC, 0, false));
        addObject(new Boundary(0, Game.SCREEN_WIDTH_FRAC, Game.SCREEN_HEIGHT_FRAC, true));
        spaceship = new Spaceship(128*Frac.UNIT, Game.SCREEN_HEIGHT_FRAC / 2);
        addObject(spaceship);
        Camera camera = new Camera(Game.SCREEN_WIDTH_FRAC / 2, Game.SCREEN_HEIGHT_FRAC / 2);
        addObject(camera);
        Viewport viewport = new Viewport(0, 0, Game.SCREEN_WIDTH_FRAC, Game.SCREEN_HEIGHT_FRAC);
        viewport.setCamera(camera);
        viewport.setHUD(new ScoreHUD(game, this));
        setViewport(0, viewport);
        setTimerValue(incrementScore, 60);
        setTimerValue(spawnAsteroid, 60);
    }
    
    @Override
    public void frameActions(CellGame game, BasicSpaceState state) {
        super.frameActions(game, state);
        if (spaceship != null && spaceship.getGameState() != this) {
            //Spaceship has just been destroyed
            spaceship = null;
            setTimerValue(incrementScore, -1);
            setTimerValue((eventGame, eventState) -> {
                this.game.fadeEnterState(Game.SID_MENU);
            }, 120);
        }
    }
    
    @Override
    public void leftActions(CellGame game) {
        this.game.recordScore(score);
    }
    
    public final int getScore() {
        return score;
    }
    
}
