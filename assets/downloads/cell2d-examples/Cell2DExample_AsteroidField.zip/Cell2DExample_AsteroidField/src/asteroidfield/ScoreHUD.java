package asteroidfield;

import org.cell2d.celick.Graphics;
import org.cell2d.space.HUD;

/**
 * An HUD that displays the current score and high score.
 * @author Andrew Heyman
 */
public class ScoreHUD implements HUD {
    
    private final Game game;
    private final InGameState state;
    
    public ScoreHUD(Game game, InGameState state) {
        this.game = game;
        this.state = state;
    }
    
    @Override
    public void renderActions(Graphics g, int x1, int y1, int x2, int y2) {
        Game.drawString("SCORE: " + state.getScore(), g, x1 + 5*Game.FONT_WIDTH, y1);
        Game.drawString("HIGH SCORE: " + game.getHighScore(), g, x1, y1 + 20);
    }
    
}
