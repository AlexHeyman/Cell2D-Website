package asteroidfield;

import org.cell2d.space.PointHitbox;
import org.cell2d.space.SpaceObject;

/**
 * A simple SpaceObject that serves as a camera for an InGameState's Viewport.
 * @author Andrew Heyman
 */
public class Camera extends SpaceObject {
    
    public Camera(long x, long y) {
        setLocatorHitbox(new PointHitbox(x, y));
    }
    
}
