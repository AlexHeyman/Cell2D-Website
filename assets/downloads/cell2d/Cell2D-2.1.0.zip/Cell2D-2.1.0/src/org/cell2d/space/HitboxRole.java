package org.cell2d.space;

/**
 * @author Andrew Heyman
 */
enum HitboxRole {
    LOCATOR, CENTER, OVERLAP, SOLID, COLLISION
}
