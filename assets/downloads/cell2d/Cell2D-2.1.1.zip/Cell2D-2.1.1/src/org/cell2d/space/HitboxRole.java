package org.cell2d.space;

/**
 * @author Alex Heyman
 */
enum HitboxRole {
    LOCATOR, CENTER, OVERLAP, SOLID, COLLISION
}
